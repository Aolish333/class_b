CREATE TRIGGER definingTicket
BEFORE INSERT ON ticket
FOR EACH ROW
  BEGIN
     IF (new.ticket_type = "学生票")
     THEN
       SET NEW.ticket_price = "15";
     ELSEIF (NEW.ticket_type = "团体票")
       THEN SET NEW.ticket_price = "25";
     ELSEIF (NEW.ticket_type = "成人票")
       THEN SET NEW.ticket_price = "30";
     ELSEIF (NEW.ticket_type = "团体票")
       THEN SET NEW.ticket_price = "25";
     ELSEIF (NEW.ticket_type = "老人票")
       THEN SET NEW.ticket_price = "20";
     ELSEIF (NEW.ticket_type = "儿童票")
       THEN SET NEW.ticket_price = "20";
     END IF;
   END;
